--[[
AdiBags - Adirelle's bag addon.
Copyright 2010-2021 Adirelle (adirelle@gmail.com)
All rights reserved.

This file is part of AdiBags.

AdiBags is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

AdiBags is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with AdiBags.  If not, see <http://www.gnu.org/licenses/>.
--]]

local addonName = ...
---@class AdiBags: ABEvent-1.0
local addon = LibStub('AceAddon-3.0'):GetAddon(addonName)
---@cast addon +ABEvent-1.0|ABBucket-1.0|AceHook-3.0|AceConsole-3.0
local L = addon.L

--<GLOBALS
local _G = _G
local ADDON_LOAD_FAILED = _G.ADDON_LOAD_FAILED
local BANK_CONTAINER = _G.BANK_CONTAINER or ( Enum.BagIndex and Enum.BagIndex.Bank ) or -1
local REAGENTBANK_CONTAINER = _G.REAGENTBANK_CONTAINER or ( Enum.BagIndex and Enum.BagIndex.Reagentbank ) or -3
local REAGENTBAG_CONTAINER = ( Enum.BagIndex and Enum.BagIndex.REAGENTBAG_CONTAINER ) or 5
-- Warbound Bank containers (added in WoW 11.0 - The War Within)
-- Using fallback values since enum names may vary between versions
local WARBOUND_BANK_CONTAINER_1 = ( Enum.BagIndex and Enum.BagIndex.AccountBankTab_1 ) or ( Enum.BagIndex and Enum.BagIndex.Warband1 ) or -5
local WARBOUND_BANK_CONTAINER_2 = ( Enum.BagIndex and Enum.BagIndex.AccountBankTab_2 ) or ( Enum.BagIndex and Enum.BagIndex.Warband2 ) or -6
local WARBOUND_BANK_CONTAINER_3 = ( Enum.BagIndex and Enum.BagIndex.AccountBankTab_3 ) or ( Enum.BagIndex and Enum.BagIndex.Warband3 ) or -7
local WARBOUND_BANK_CONTAINER_4 = ( Enum.BagIndex and Enum.BagIndex.AccountBankTab_4 ) or ( Enum.BagIndex and Enum.BagIndex.Warband4 ) or -8
local WARBOUND_BANK_CONTAINER_5 = ( Enum.BagIndex and Enum.BagIndex.AccountBankTab_5 ) or ( Enum.BagIndex and Enum.BagIndex.Warband5 ) or -9
local CloseWindows = _G.CloseWindows
local CreateFrame = _G.CreateFrame
local format = _G.format
local GetBuildInfo = _G.GetBuildInfo
local GetCVarBool = _G.GetCVarBool
local geterrorhandler = _G.geterrorhandler
local Settings = _G.Settings
local LoadAddOn = _G.C_AddOns.LoadAddOn
local next = _G.next
local NUM_BANKGENERIC_SLOTS = _G.NUM_BANKGENERIC_SLOTS or 28
local pairs = _G.pairs
local pcall = _G.pcall
local print = _G.print
local strmatch = _G.strmatch
local strsplit = _G.strsplit
local type = _G.type
local wipe = _G.wipe
---@diagnostic disable-next-line: deprecated
local unpack = _G.unpack
--GLOBALS>

--------------------------------------------------------------------------------
-- Addon initialization and enabling
--------------------------------------------------------------------------------

--[===[@debug@
local function DebugTable(t, prevKey)
	local k, v = next(t, prevKey)
	if k ~= nil then
		return k, v, DebugTable(t, k)
	end
end
--@end-debug@]===]

-- Define bag keys based on WoW version
local bagKeys = {"backpack", "bank"}
local interfaceVersion = select(4, GetBuildInfo())
if not addon.isModernRetail then
	-- The modern Mainline-family bank does not use legacy reagent bank tabs
	table.insert(bagKeys, "reagentBank")
end
if addon.isRetail and not addon.useBlizzardBank and interfaceVersion >= 110000 then
	-- Only the legacy tab implementation can use this mapping (The War Within) - retail only
	table.insert(bagKeys, "warbandbank")  -- lowercase to match theme lookup
end
function addon:OnInitialize()
	-- One-time migration: WoW loads SavedVariables by the AddOn's folder name.
	-- The user must copy WTF/.../SavedVariables/AdiBagsEx.lua to
	-- WTF/.../SavedVariables/AdiBags_FE.lua while the game is closed.
	-- If the old global is available then, import it into the new namespace.
	-- NEVER overwrite settings that already exist for AdiBags_FE.
	if type(_G.AdiBagsForeverDB) ~= 'table' then
		if type(_G.AdiBagsExDB) == 'table' then
			_G.AdiBagsForeverDB = _G.AdiBagsExDB
			print('|cff00ff00AdiBags_FE:|r Einstellungen aus AdiBagsEx uebernommen.')
		elseif type(_G.AdiBagsTDB) == 'table' then
			_G.AdiBagsForeverDB = _G.AdiBagsTDB
			print('|cff00ff00AdiBags_FE:|r Einstellungen aus AdiBagsT uebernommen.')
		end
	end

	-- Create the default font settings for each bag type.
	for _, name in ipairs(bagKeys) do
		-- Ensure the theme entry exists for this bag type
		if not addon.DEFAULT_SETTINGS.profile.theme[name] then
			addon.DEFAULT_SETTINGS.profile.theme[name] = {
				background = "Blizzard Dialog Background",
				border = "Blizzard Tooltip",
				borderWidth = 16,
				insets = 3,
				color = name == "warbandbank" and { 0.5, 0, 0.5, 1 } or { 0, 0, 0, 1 },
				bagFont = addon.BagFontDefault,
				sectionFont = addon.SectionFontDefault,
			}
		end
		
		local bfd = self:GetFontDefaults(GameFontHighlightLarge)
		bfd.r, bfd.g, bfd.b = 1, 1, 1
		addon.DEFAULT_SETTINGS.profile.theme[name].bagFont = bfd
		addon.DEFAULT_SETTINGS.profile.theme[name].sectionFont = self:GetFontDefaults(GameFontNormalLeft)
	end

	self.db = LibStub('AceDB-3.0'):New(addonName.."DB", addon.DEFAULT_SETTINGS, true)
	self.db.RegisterCallback(self, "OnProfileChanged", "OnProfileChanged")
	self.db.RegisterCallback(self, "OnProfileCopied", "OnProfileChanged")
	self.db.RegisterCallback(self, "OnProfileReset", "Reconfigure")

	self:UpgradeProfile()

	-- Initialize experiments now that the database is ready
	local Experiments = self:GetModule("Experiments")
	if Experiments and Experiments.CreateAllExperiments then
		Experiments:CreateAllExperiments()
	end

	-- Create the bag font objects.
	---@type table<string, table<string, AdiFont|Font>>
	self.fonts = {}
	for _, name in ipairs(bagKeys) do
		self.fonts[name] = {
			bagFont = self:CreateFont(addonName..name.."BagFont", GameFontHighlightLarge, function() return addon.db.profile.theme[name].bagFont end),
			sectionFont = self:CreateFont(addonName..name.."SectionFont", GameFontNormalLeft, function() return addon.db.profile.theme[name].sectionFont end)
		}
	end

	self.itemParentFrames = {}

	self:InitializeFilters()
	self:CreateBagAnchor()

	self:SetEnabledState(false)

	-- Persistant handlers
	self.RegisterBucketMessage(addonName, 'AdiBags_FE_ConfigChanged', 0.2, function(...) addon:ConfigChanged(...) end)
	self.RegisterEvent(addonName, 'PLAYER_ENTERING_WORLD', function() if self.db.profile.enabled then self:Enable() end end)

	self:RegisterChatCommand("adibagsforever", function(cmd)
		if cmd and cmd:trim() ~= "" then
			local args = {strsplit(' ', cmd:trim())}
			-- Filter out empty strings
			local filteredArgs = {}
			for i, arg in ipairs(args) do
				if arg and arg ~= "" then
					table.insert(filteredArgs, arg)
				end
			end
			addon:OpenOptions(unpack(filteredArgs))
		else
			addon:OpenOptions()
		end
	end, true)

	-- Read-only Forever bank diagnostic. Does not list item contents.
	if addon.isForever then
		self:RegisterChatCommand("abfbankdebug", function()
			local b = _G.C_Bank
			local c = _G.C_Container
			local kind = _G.Enum and _G.Enum.BankType and _G.Enum.BankType.Character
			print("AdiBagsForever: Charakterbank-API", b and "vorhanden" or "nicht vorhanden")
			if not b or not b.FetchPurchasedBankTabIDs or kind == nil then return end
			local ids = b.FetchPurchasedBankTabIDs(kind)
			if type(ids) ~= "table" then
				print("AdiBagsForever: Keine Bank-Tabs auslesbar. Bitte beim Bankier testen.")
				return
			end
			local text = {}
			for _, id in ipairs(ids) do
				local n = c and c.GetContainerNumSlots and c.GetContainerNumSlots(id) or "?"
				text[#text + 1] = tostring(id) .. ":" .. tostring(n)
			end
			print("AdiBagsForever: Bank-Tabs (ID:Slots): " .. table.concat(text, ", "))
		end, true)
	end

	if addon.isRetail and not addon.isForever and C_CVar then
		-- Tutorials differ on Forever; do not alter unrelated CVars there.
		if C_CVar.SetCVarBitfield and LE_FRAME_TUTORIAL_EQUIP_REAGENT_BAG then
			C_CVar.SetCVarBitfield("closedInfoFrames", LE_FRAME_TUTORIAL_EQUIP_REAGENT_BAG, true)
		end
		if C_CVar.SetCVar then
			C_CVar.SetCVar("professionToolSlotsExampleShown", 1)
			C_CVar.SetCVar("professionAccessorySlotsExampleShown", 1)
		end
	end

	self:Debug('Initialized')
end

--------------------------------------------------------------------------------
-- Event Handlers (must be defined before OnEnable)
--------------------------------------------------------------------------------

local updatedBags = {}
local updatedBank = addon.isForever and addon.BAG_IDS.BANK_ONLY or { [BANK_CONTAINER] = true }
local updatedReagentBank = {}
local updatedWarboundBank = {}
-- Check if reagent bank is available in this version
local interfaceVersion = select(4, GetBuildInfo())
if addon.isRetail and not addon.isModernRetail then
	-- The old reagent bank belongs to older clients
	updatedReagentBank = { [REAGENTBANK_CONTAINER] = true }
end
-- Check if warbound bank is available in this version
if addon.isRetail and not addon.useBlizzardBank and interfaceVersion >= 110000 then
	-- Only the legacy tab implementation can use this mapping (The War Within)
	updatedWarboundBank = {
		[WARBOUND_BANK_CONTAINER_1] = true,
		[WARBOUND_BANK_CONTAINER_2] = true,
		[WARBOUND_BANK_CONTAINER_3] = true,
		[WARBOUND_BANK_CONTAINER_4] = true,
		[WARBOUND_BANK_CONTAINER_5] = true,
	}
end

function addon:BAG_UPDATE(event, bag)
	updatedBags[bag] = true
	
	-- Check if reagent bank is available and handle accordingly
	local interfaceVersion = select(4, GetBuildInfo())
	if bag == REAGENTBANK_CONTAINER then
		if addon.isModernRetail then
			-- Modern clients have no legacy reagent-bank container
			return
		else
			-- For older versions, handle reagent bank updates
			self:SendMessage('AdiBags_BagUpdated', updatedReagentBank)
			return
		end
	end
	
	-- Check if warbound bank and handle accordingly
	if addon.isRetail and not addon.useBlizzardBank and interfaceVersion >= 110000 then
		if bag == WARBOUND_BANK_CONTAINER_1 or bag == WARBOUND_BANK_CONTAINER_2 or 
		   bag == WARBOUND_BANK_CONTAINER_3 or bag == WARBOUND_BANK_CONTAINER_4 or 
		   bag == WARBOUND_BANK_CONTAINER_5 then
			self:SendMessage('AdiBags_BagUpdated', updatedWarboundBank)
			return
		end
	end
	
	if addon.isRetail or addon.isWrath or addon.isCata then
		self:SendMessage('AdiBags_BagUpdated', updatedBags)
		wipe(updatedBags)
	end
end

function addon:BAG_UPDATE_DELAYED(event)
	self:SendMessage('AdiBags_BagUpdated', updatedBags)
	wipe(updatedBags)
end

function addon:BankUpdated(slots)
	-- Wrap several PLAYERBANKSLOTS_CHANGED into one AdiBags_BagUpdated message
	for slot in pairs(slots) do
		if slot > 0 and slot <= NUM_BANKGENERIC_SLOTS then
			return self:SendMessage('AdiBags_BagUpdated', updatedBank)
		end
	end
end

function addon:ReagentBankUpdated(slots)
	-- Wrap several PLAYERREAGANBANKSLOTS_CHANGED into one AdiBags_BagUpdated message
	for slot in pairs(slots) do
		if slot > 0 and slot <= 98 then
			return self:SendMessage('AdiBags_BagUpdated', updatedReagentBank)
		end
	end
end

function addon:OnEnable()

	self.globalLock = false

	self:RegisterEvent('BAG_UPDATE')
	self:RegisterEvent('BAG_UPDATE_DELAYED')
	if not addon.useBlizzardBank then
		self:RegisterBucketEvent('PLAYERBANKSLOTS_CHANGED', 0.01, 'BankUpdated')
	end
	
	-- PLAYERREAGENTBANKSLOTS_CHANGED was removed in WoW 11.2.0 for all versions
	-- Reagent bank updates are now handled by BAG_UPDATE event
	local interfaceVersion = select(4, GetBuildInfo())
	if not addon.isModernRetail then
		self:RegisterBucketEvent('PLAYERREAGENTBANKSLOTS_CHANGED', 0.01, 'ReagentBankUpdated')
	end

	self:RegisterEvent('PLAYER_LEAVING_WORLD', 'Disable')

	self:RegisterMessage('AdiBags_BagOpened', 'LayoutBags')
	self:RegisterMessage('AdiBags_BagClosed', 'LayoutBags')
	
	-- Track most windows involving items
	if addon.isRetail or addon.isWrath or addon.isCata then
		self:RegisterEvent('PLAYER_INTERACTION_MANAGER_FRAME_SHOW', 'UpdateInteractingFrame')
		self:RegisterEvent('PLAYER_INTERACTION_MANAGER_FRAME_HIDE', 'UpdateInteractingFrame')
		-- TODO(lobato): This is a hack to fix a change in the timing of the interaction manager
		-- event. The interaction manager frame event is fired later than the bankframe opened
		-- event is, which causes a race somewhere else in our code. Without this, GetInteractingWindow
		-- will return a nil value when it shouldn't. We need to figure out where this race is
		-- happening and fix it properly.
		-- Note, this seems to only happen with the bankframe event, and no others.
		self:RegisterEvent('BANKFRAME_OPENED', 'UpdateInteractingWindow')
	else
		self:RegisterEvent('BANKFRAME_OPENED', 'UpdateInteractingWindow')
		self:RegisterEvent('BANKFRAME_CLOSED', 'UpdateInteractingWindow')
		self:RegisterEvent('MAIL_SHOW', 'UpdateInteractingWindow')
		self:RegisterEvent('MAIL_CLOSED', 'UpdateInteractingWindow')
		self:RegisterEvent('MERCHANT_SHOW', 'UpdateInteractingWindow')
		self:RegisterEvent('MERCHANT_CLOSED', 'UpdateInteractingWindow')
		self:RegisterEvent('AUCTION_HOUSE_SHOW', 'UpdateInteractingWindow')
		self:RegisterEvent('AUCTION_HOUSE_CLOSED', 'UpdateInteractingWindow')
		self:RegisterEvent('TRADE_SHOW', 'UpdateInteractingWindow')
		self:RegisterEvent('TRADE_CLOSED', 'UpdateInteractingWindow')
		self:RegisterEvent('GUILDBANKFRAME_OPENED', 'UpdateInteractingWindow')
		self:RegisterEvent('GUILDBANKFRAME_CLOSED', 'UpdateInteractingWindow')
		self:RegisterEvent('SOCKET_INFO_UPDATE', 'UpdateInteractingWindow')
		self:RegisterEvent('SOCKET_INFO_CLOSE', 'UpdateInteractingWindow')
	end
	if self.db and self.db.profile then
		self:SetSortingOrder(self.db.profile.sortingOrder)
	else
		addon:Debug('Database not ready in OnEnable, skipping SetSortingOrder')
		return
	end

	for name, module in self:IterateModules() do
		---@cast module +AceModule|FilterModule
		if self.db and self.db.profile then
			if module.isFilter then
				module:SetEnabledState(self.db.profile.filters[module.moduleName])
			elseif module.isBag then
				-- Never hide/hook Forever's tabbed Blizzard bank with legacy code.
				-- Forever: only the new *character* bank companion is supported.
				local permitted = not (addon.useBlizzardBank and module.isBank)
					or (addon.isForever and module.bagName == "Bank")
				module:SetEnabledState(permitted and self.db.profile.bags[module.bagName])
			else
				-- BankSwitcher assumes the retired bank layout and item transfers.
				module:SetEnabledState(not (addon.useBlizzardBank and module.moduleName == "BankSwitcher")
					and self.db.profile.modules[module.moduleName])
			end
		end
	end

	if self.fonts then
		for _, name in ipairs(bagKeys) do
			if self.fonts[name] then
				self.fonts[name].bagFont:ApplySettings()
				self.fonts[name].sectionFont:ApplySettings()
			end
		end
	end

	self:UpdatePositionMode()

	self:Debug('Enabled')
end

function addon:OnDisable()
	self.anchor:Hide()
	self:CloseAllBags()
	self:Debug('Disabled')
end

-- Hook only globals that actually exist on the running Mainline-family client.
local bagHookNames = {
	OpenAllBags = true, ToggleAllBags = true, ToggleBackpack = true,
	ToggleBag = true, OpenBag = true, OpenBackpack = true,
	CloseAllBags = false, CloseBag = false, CloseBackpack = false,
	CloseSpecialWindows = false,
}
function addon:EnableHooks()
	self.foreverActiveHooks = {}
	for name, isRaw in pairs(bagHookNames) do
		if type(_G[name]) == "function" and type(self[name]) == "function" then
			if isRaw then self:RawHook(name, true) else self:SecureHook(name) end
			self.foreverActiveHooks[name] = true
		end
	end
end

function addon:DisableHooks()
	for name in pairs(self.foreverActiveHooks or {}) do
		if self:IsHooked(name) then self:Unhook(name) end
	end
	self.foreverActiveHooks = nil
end

function addon:Reconfigure()
	self.holdYourBreath = true -- prevent tons*$% of useless updates
	self:Disable()
	self:Enable()
	self.holdYourBreath = nil
	self:UpdateFilters()
end

function addon:OnProfileChanged()
	self:UpgradeProfile()
	return self:Reconfigure()
end

-- Thanks to Talyrius for this idea
-- TODO(lobato): Remove this update code in a future version
local prevSkinPreset = {
  BackpackColor = { 0, 0, 0, 1 },
  BankColor = { 0, 0, 0.5, 1 },
  ReagentBankColor = { 0, 0.5, 0, 1 },
  WarboundBankColor = { 0.5, 0, 0.5, 1 }, -- Purple for Warbound Bank
}

function addon:UpgradeProfile()
	-- Ensure new theme entries exist for existing profiles
	for _, name in ipairs(bagKeys) do
		if not self.db.profile.theme[name] then
			self.db.profile.theme[name] = {
				background = "Blizzard Dialog Background",
				border = "Blizzard Tooltip", 
				borderWidth = 16,
				insets = 3,
				color = name == "warbandbank" and { 0.5, 0, 0.5, 1 } or { 0, 0, 0, 1 },
				bagFont = self:GetFontDefaults(GameFontHighlightLarge),
				sectionFont = self:GetFontDefaults(GameFontNormalLeft),
			}
		end
	end
	
	-- Copy over skin settings to the new theme format.
	local skin = addon.db.profile.skin
	if skin then
		for _, key in ipairs(bagKeys) do
			-- Update the basic theme data.
			addon.db.profile.theme[key].background = skin.background
			addon.db.profile.theme[key].border = skin.border
			addon.db.profile.theme[key].insets = skin.insets
			addon.db.profile.theme[key].borderWidth = skin.borderWidth

			-- Update font data, taking care not to create a new table as this breaks the font object.
			if addon.db.profile.bagFont then
				for k, v in pairs(addon.db.profile.bagFont) do
					addon.db.profile.theme[key].bagFont[k] = v
				end
			end
			if addon.db.profile.sectionFont then
				for k, v in pairs(addon.db.profile.sectionFont) do
					addon.db.profile.theme[key].sectionFont[k] = v
				end
			end

			-- Update the color data.
			if key == "backpack" and skin.BackpackColor then
				for i, v in ipairs(prevSkinPreset.BackpackColor) do
					v = skin.BackpackColor[i] or v
					addon.db.profile.theme[key].color[i] = v
				end
			elseif key == "bank" and skin.BankColor then
				for i, v in ipairs(prevSkinPreset.BankColor) do
					v = skin.BankColor[i] or v
					addon.db.profile.theme[key].color[i] = v
				end
			elseif key == "reagentBank" and skin.ReagentBankColor then
				for i, v in ipairs(prevSkinPreset.ReagentBankColor) do
					v = skin.ReagentBankColor[i] or v
					addon.db.profile.theme[key].color[i] = v
				end
			elseif key == "warbandbank" and skin.WarboundBankColor then
				for i, v in ipairs(prevSkinPreset.WarboundBankColor) do
					v = skin.WarboundBankColor[i] or v
					addon.db.profile.theme[key].color[i] = v
				end
			end
		end

		-- Delete the old skin and font profile data.
		addon.db.profile.skin = nil
		addon.db.profile.bagFont = nil
		addon.db.profile.sectionFont = nil
		addon.db.profile.theme.currentTheme = "legacy theme"
		addon:SaveTheme()
	end
end

--------------------------------------------------------------------------------
-- Option addon handling
--------------------------------------------------------------------------------

do
	local configAddonName = "AdiBags_FE_Config"
	local why = '???'
	local function CouldNotLoad()
		print("|cffff0000AdiBags_FE:", format(ADDON_LOAD_FAILED, configAddonName, why), "|r")
	end
	function addon:OpenOptions(...)
		self.OpenOptions = CouldNotLoad
		local loaded, reason = LoadAddOn(configAddonName)
		if not loaded then
			why = _G['ADDON_'..reason]
		end
		addon:OpenOptions(...)
	end
end

do
	-- Create the Blizzard addon option frame
	local panel = CreateFrame("Frame", addonName.."BlizzOptions")
	panel.name = addonName
	Settings.RegisterAddOnCategory(Settings.RegisterCanvasLayoutCategory(panel, addonName))

	local fs = panel:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
	fs:SetPoint("TOPLEFT", 10, -15)
	fs:SetPoint("BOTTOMRIGHT", panel, "TOPRIGHT", 10, -45)
	fs:SetJustifyH("LEFT")
	fs:SetJustifyV("TOP")
	fs:SetText(addonName)

	local button = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
	button:SetText(L['Configure'])
	button:SetWidth(128)
	button:SetPoint("TOPLEFT", 10, -48)
	button:SetScript('OnClick', function()
		while CloseWindows() do end
		return addon:OpenOptions()
	end)

end

function addon:ConfigChanged(vars)
	--[===[@debug@
	self:Debug('ConfigChanged', DebugTable(vars))
	--@end-debug@]===]
	if vars.enabled then
		if self.db.profile.enabled then
			self:Enable()
		else
			self:Disable()
		end
		return
	elseif not self:IsEnabled() then
		return
	elseif vars.filter then
		return self:SendMessage('AdiBags_FE_FiltersChanged')
	else
		for name in pairs(vars) do
			if strmatch(name, 'virtualStacks') then
				return self:SendMessage('AdiBags_FE_FiltersChanged')
			elseif strmatch(name, 'bags%.') then
				local _, bagName = strsplit('.', name)
				local bag = self:GetModule(bagName)
				local enabled = self.db.profile.bags[bagName]
				if addon.useBlizzardBank and bag.isBank
					and not (addon.isForever and bag.bagName == "Bank") then
					enabled = false
				end
				if enabled and not bag:IsEnabled() then
					bag:Enable()
				elseif not enabled and bag:IsEnabled() then
					bag:Disable()
				end
			elseif strmatch(name, 'columnWidth') then
				return self:SendMessage('AdiBags_FE_LayoutChanged')
			end
		end
	end
	if vars.sortingOrder then
		return self:SetSortingOrder(self.db.profile.sortingOrder)
	elseif vars.maxHeight then
		return self:SendMessage('AdiBags_FE_LayoutChanged')
	elseif vars.scale then
		return self:LayoutBags()
	elseif vars.positionMode then
		return self:UpdatePositionMode()
	else
		self:SendMessage('AdiBags_UpdateAllButtons')
	end
end

function addon:SetGlobalLock(locked)
	locked = not not locked
	if locked ~= self.globalLock then
		self.globalLock = locked
		self:SendMessage('AdiBags_GlobalLockChanged', locked)
		if not locked then
			self:SendMessage('AdiBags_FE_LayoutChanged')
		end
		return true
	end
end

--------------------------------------------------------------------------------
-- Track windows related to item interaction (merchant, mail, bank, ...)
--------------------------------------------------------------------------------

do
	local current
	function addon:UpdateInteractingWindow(event, ...)
		local new = strmatch(event, '^([_%w]+)_OPEN') or strmatch(event, '^([_%w]+)_SHOW$') or strmatch(event, '^([_%w]+)_UPDATE$')
		self:Debug('UpdateInteractingWindow', event, current, '=>', new, '|', ...)
		if new ~= current then
			local old = current
			current = new
			self.atBank = (current == "BANKFRAME")
			if self.db.profile.virtualStacks.notWhenTrading ~= 0 then
				self:SendMessage('AdiBags_FE_FiltersChanged', true)
			end
			self:SendMessage('AdiBags_InteractingWindowChanged', new, old)
		end
	end

	function addon:UpdateInteractingFrame(event, kind)
		local new
		if event == "PLAYER_INTERACTION_MANAGER_FRAME_SHOW" then
			if kind == Enum.PlayerInteractionType.Banker then
				new = "BANKFRAME"
			elseif kind == Enum.PlayerInteractionType.Merchant or
			kind == Enum.PlayerInteractionType.Auctioneer or
			kind == Enum.PlayerInteractionType.BlackMarketAuctioneer or
			kind == Enum.PlayerInteractionType.TradePartner or
			kind == Enum.PlayerInteractionType.MailInfo then
				new = "MERCHANT"
			end
		end
		self:Debug('UpdateInteractingFrame', event, current, '=>', new, '|', kind)
		if new ~= current then
			local old = current
			current = new
			self.atBank = (current == "BANKFRAME")
			if self.db.profile.virtualStacks.notWhenTrading ~= 0 then
				self:SendMessage('AdiBags_FE_FiltersChanged', true)
			end
			self:SendMessage('AdiBags_InteractingWindowChanged', new, old)
		end
	end

	function addon:GetInteractingWindow()
		return current
	end
end

--------------------------------------------------------------------------------
-- Virtual stacks
--------------------------------------------------------------------------------

function addon:ShouldStack(slotData)
	local conf = self.db.profile.virtualStacks
	local hintSuffix = '#'..tostring(slotData.bagFamily)
	if not slotData.link then
		return conf.freeSpace, "*Free*"..hintSuffix
	end
	if not self.db.profile.showBagType then
		hintSuffix = ''
	end
	local window, unstack = self:GetInteractingWindow(), 0
	if window then
		unstack = conf.notWhenTrading
		if unstack >= 4 and window ~= "BANKFRAME" then
			return
		end
	end
	-- Do not virtually merge different physical gear instances: one GUID
	-- may have been worn while an otherwise identical GUID has not.
	if self.isForever and self.IsWearableEquipment and
		self.db.profile.filters.WornEquipment and self.IsWearableEquipment(slotData.equipSlot) then
		return false
	end
	local maxStack = slotData.maxStack or 1
	if maxStack > 1 then
		if conf.stackable then
			if (slotData.count or 1) == maxStack then
				return true, tostring(slotData.itemId)..hintSuffix
			elseif unstack < 3 then
				return conf.incomplete, tostring(slotData.itemId)..hintSuffix
			end
		end
	elseif conf.others and unstack < 2 then
		return true, tostring(self.GetDistinctItemID(slotData.link))..hintSuffix
	end
end

--------------------------------------------------------------------------------
-- Skin-related methods
--------------------------------------------------------------------------------

local LSM = LibStub('LibSharedMedia-3.0')

function addon:GetContainerSkin(containerName, isReagentBank)
	local skin
	if isReagentBank then
		skin = addon.db.profile.theme.reagentBank
	else
		skin = addon.db.profile.theme[string.lower(containerName)]
	end

	local r, g, b, a = unpack(skin.color, 1, 4)
	local backdrop = addon.BACKDROP
	backdrop.bgFile = LSM:Fetch(LSM.MediaType.BACKGROUND, skin.background)
	backdrop.edgeFile = LSM:Fetch(LSM.MediaType.BORDER, skin.border)
	backdrop.edgeSize = skin.borderWidth
	backdrop.insets.left = skin.insets
	backdrop.insets.right = skin.insets
	backdrop.insets.top = skin.insets
	backdrop.insets.bottom = skin.insets
	return backdrop, r, g, b, a
end
